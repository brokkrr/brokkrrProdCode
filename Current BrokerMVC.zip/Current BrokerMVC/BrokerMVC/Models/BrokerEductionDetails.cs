﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BrokerMVC.Models
{
    public class BrokerEductionDetails
    {
        public string Eduction { get; set; }
        public string Eduction1 { get; set; }
        public string Eduction2 { get; set; }
        public string Eduction3 { get; set; }
        public string Eduction4 { get; set; }


    }
}