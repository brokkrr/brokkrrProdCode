﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BrokerMVC.Models
{
    public class BrokerCompanyDetails
    {
        public string CompanyName { get; set; }
        public string CompanyName1 { get; set; }
        public string CompanyName2 { get; set; }
        public string CompanyName3 { get; set; }
        public string CompanyName4 { get; set; }
    }
}